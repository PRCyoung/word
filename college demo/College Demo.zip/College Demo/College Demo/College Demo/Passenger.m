//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"
#import "math.h"

@implementation Orders

@end

@implementation Passenger
// 去订票
- (BOOL)BookOrders:(NSDate *)departuretime departureaddress:(Address *)departureaddress destinationaddress:(Address *)destinationaddress{
        
    BOOL result=YES;
    srand((unsigned)time(NULL));
    Orders *order = [Orders new];

    int orderid=rand() % (int)pow(10, 6);
    order.OrderID = [NSString stringWithFormat:@"%0.6d",orderid];
    
    order.DepartureTime = departuretime;
    order.DepartureAddress = departureaddress;
    order.DestinationAddress = destinationaddress;
    
    int seatid=rand() % 30;
    order.SeatID = [NSString stringWithFormat:@"%0.2d",seatid];
    
    [self.HistoryOrders addObject:order];
    [self.PendingOrders addObject:order];
        
    return result;
}

// 去检票
- (BOOL)CheckOrders:(NSString *)name orderid:(NSString *)orderid{
    
    Orders *order = [Orders new];
    BOOL result = YES|NO;
    for(order in self.PendingOrders)
    {
        if([orderid isEqualToString:order.OrderID] && [name isEqualToString:self.name])
        {
            [self.PendingOrders removeLastObject];
            result = YES;break;
        }
        else result = NO;
    }

    return result;
}
@end
